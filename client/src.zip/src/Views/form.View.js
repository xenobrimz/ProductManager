import React from 'react'
import ProductForm from '../Components/productCreateForm.Component';
const Form = () => {
    return (
        <div>
           <ProductForm/>
        </div>
    )
}

export default Form

